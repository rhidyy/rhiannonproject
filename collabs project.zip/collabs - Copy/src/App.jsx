import { createBrowserRouter, Route, createRoutesFromElements, RouterProvider } from "react-router-dom"
import Home from "./pages/Home"
import Notes from "./pages/Notes"
import Todo from "./pages/Todo"
import RootLayout from "./layouts/RootLayout"
import Messages from "./pages/Messages"


const router = createBrowserRouter(
  createRoutesFromElements(
    <Route path='/' element={<RootLayout/>}>
    <Route index element={<Home/>}/>
    <Route path='notes' element={<Notes/>} />
    <Route path='todo' element={<Todo/>}/>
    <Route path='messages' element={<Messages/>}/>
  </Route>
  )
)

function App() {

  return (
     
   <RouterProvider router={router}/>
  )
}

export default App
