import React from 'react'

export default function Messages() {
  return (
    <div>Messages</div>
  )
}
