import { NavLink, Outlet } from "react-router-dom"

export default function RootLayout() {
  return (
    <div className='root-layout'>
        <header>
            <nav>
                <h1>Collabs</h1>
                <NavLink to='/'>Home</NavLink>
                <NavLink to='notes'>Notes</NavLink>
                <NavLink to='todo'>Todo</NavLink>
                <NavLink to='messages'>Messages</NavLink>
            </nav>
        </header>

        <main>
            <Outlet/>
        </main>

    </div>
  )
}
